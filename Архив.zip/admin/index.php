<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8" />
	<link rel="icon" type="image/svg+xml" href="./vite.svg" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>Vite + React + TS</title>
	<script type="module" crossorigin src="<?php echo get_template_directory_uri(); ?>/admin/index.js"></script>
	<link rel="stylesheet" crossorigin href="<?php echo get_template_directory_uri(); ?>/admin/style.css">
</head>

<body>
	<div id="abit-admin"></div>
</body>

</html>